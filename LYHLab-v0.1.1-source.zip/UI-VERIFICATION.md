# iOS UI 0.1.1

原生 SwiftUI 视觉与交互更新，最低 iOS 16。Bundle ID `cn.lyhlab.procurement` 未变；版本 0.1.1、构建号 2。

- 深墨与品牌绿 LYH LAB 视觉、白卡片、原生 NavigationStack、搜索、状态分段。
- 项目汇总与采购记录层次分离；项目选择使用独立 sheet，不混合项目数据。
- 主操作“添加采购记录”；导航栏独立导出入口。报表仍限当前项目。
- 录入 sheet 优先名称、状态和实付总额；数量和备注可展开。
- 未修改 API.swift、Models.swift，文件 SHA256 与原版本完全相同。未触碰服务端、TLS、Cookie、CSRF、账户或权限策略。

已运行 `python3 verify_source.py`：项目引用、scheme XML、API 路径与安全结构检查通过。
人工检查避免使用 iOS 17 才提供的简写 Button 标题/图标初始化方式，使用 iOS 16 可用的 Label 构造；保留 FileDocument 与系统导出流程。

**当前没有 Swift 编译器、Xcode、iOS SDK 或模拟器。未编译、未运行、未签名；不能将此源码称为可安装 IPA，也不能把设计预览称为实机截图。**

后续必须在 Xcode 构建并核验动态字体、键盘与 sheet 布局、首次登录、项目切换、记录保存、报表导出。

## Distribution checkpoint (after delivery)
Liu approved the iPhone design direction and asked how to install; there was
no request to buy hosting/membership, upload source, or select a distribution
route. Preview and source ZIP were delivered in chat, not an IPA. Recheck for
an existing eligible Apple development team and trusted Xcode host before
proposing spending. Build and test first; keep existing website auth and data
unchanged. Never request an Apple password or signing private key in chat.

Apple: an internal TestFlight build is a renewable beta, available for up to
90 days, and its testers must already have appropriate App Store Connect app
access. Do not represent it as permanent or use an unrelated team by default.
Xcode Cloud still needs an eligible Apple Developer Program team, source
control, and initial workflow configuration in Xcode; no Linux-only shortcut.
- https://developer.apple.com/help/app-store-connect/test-a-beta-version/add-internal-testers
- https://developer.apple.com/xcode-cloud/get-started/
