# 项目采购管理 iOS 原生源码（未编译、未签名）

2026-11-15。SwiftUI，iOS 16+，iPhone/iPad 自适应；非 WebView、非 PWA。此目录不是可安装 IPA，也没有经过真机验收。

## 已实现于源码
- 适配网站 V0.4.4 项目采购 API。管理员账号登录、服务端会话核验、退出；客户账号不可进入账本。
- 与网站共用 `/api/admin/purchases`，不另建账本或导入副本。
- 必须选择项目，优先默认 DWARF 智能天文台。列表与 CSV 都用 project_id 筛选，新增携带当前 project_id；不请求全局混合账本。
- 列表、当前项目内名称搜索、待买/已买筛选、汇总、下拉刷新。
- 新增只填名称（默认数量 1、待买）；实付总额录入自动切换已买；数量、备注可编辑；不在手机端静默迁移所属项目。
- 编辑保留未知数量/金额为 null；金额采用整数分，不把未知当零；来源只读。
- 原生 CSV 导出系统文件选择器，报表直接使用服务端生成结果。
- 不提供采购归档/删除、打印机控制、后台任务或任何额外服务访问。

## 安全与数据
公开源码不内置生产网站地址。登录页填写完整 HTTPS 网站地址；只允许根地址，可带端口，不允许用户名、密码、路径、查询或片段。地址仅存在运行内存。登录前核对目标网站，账号密码仅发到你填写的该站点。
正常验证系统信任链与主机名，不配置 ATS 例外，不忽略证书错误，不接受 HTTP，拒绝所有重定向。
账号密码只用于主动登录；密码输入随即清空。会话 Cookie 与 CSRF token 仅存在进程内存，不写入 UserDefaults、Keychain 或磁盘 cookie jar。关闭进程后需重新登录。应用后台未被终止时会话仍可能有效，服务端最长有效期由网站控制。
私有账本仅驻留内存；用户主动导出的 CSV 才写入其选择的位置。不会向分析、广告或模型服务发送数据。
POST/PATCH 必须带 CSRF；网络超时不自动重试。保存结果不确定时，关闭并刷新核对，防止重复记账。
网络连接失败不得通过关闭 TLS 校验来修复，应修复服务器证书/域名。

## 当前验证范围及确切阻碍
当前执行环境是 Linux，没有 `swift`、`xcodebuild`、Apple SDK 或已连接 Mac。仅运行了 `python3 verify_source.py`：项目引用、scheme XML、API 路径、TLS/登录约束、未知值与防重复路径静态检查通过。
未声称编译通过、界面截图通过、iPhone 可安装或生产登录/写入测试通过。没有使用生产账号测试，没有改动生产服务器。
模型数值测试源码在 Tests/ModelsSmoke.swift，待具有 Swift 工具链的环境运行；不是已经通过的测试。
此外还未获得可用于本项目的 Apple 开发团队/签名授权；没有创建 Apple 账号、收集密码/私钥、支付费用、上传 App Store Connect 或提交审核。

## 接下来由开发执行环境完成的验证（不是要求用户复制命令）
在兼容 macOS 上安装 Apple 官方 Xcode，打开 LYHLab.xcodeproj：
1. 先无签名模拟器构建并检查中文布局、大字体、横竖屏、手机与 iPad。
2. 运行独立模型测试：
   `swiftc LYHLab/Models.swift Tests/ModelsSmoke.swift -o /tmp/lyhlab-model-tests && /tmp/lyhlab-model-tests`
3. 使用隔离测试服务器/测试管理员验证登录→新增→修改→刷新→导出→登出；核对网页同步与重启后保存。
4. 检查无登录 401、普通客户 403、会话过期、证书错误、离线/请求中断不重复保存。
5. 核验已附 App 图标，补齐发布元数据、隐私说明，配置项目唯一 Bundle ID 和合法 Signing Team，归档后真机验收。

可使用：
`xcodebuild -project LYHLab.xcodeproj -scheme LYHLab -sdk iphonesimulator -configuration Debug CODE_SIGNING_ALLOWED=NO build`

这一步即使成功也只代表模拟器构建，不是签名 IPA。最终支持的 Xcode/macOS 组合按 Apple 最新兼容表核实。

## iPhone 安装方式：不能将源码或未签名 IPA 当作安装包
- 免费 Personal Team 可用于个人设备开发测试；Apple 说明其设备安装配置文件 7 天到期，可能需要重建重装，不等于长期可下载分发。
- TestFlight：需要 Apple Developer Program 与 App Store Connect 的合法团队/权限，上传签名构建并按 Apple 流程分发，部分测试分发需审核；用户通过 TestFlight 安装，不是普通网站裸 IPA。
- Ad Hoc：需要适用的 Developer Program 资格、注册目标设备、对应签名及 provisioning profile，导出的 IPA 仅适用已纳入的设备，不能任意 iPhone 下载即装。
- App Store：另外需要发布材料与审核；本次未提交。

官方依据（2026-11-15 查阅）：
- [Apple 开发者账号与 Personal Team 限制](https://developer.apple.com/help/account/basics/about-your-developer-account)
- [Xcode/macOS SDK 兼容要求](https://developer.apple.com/xcode/system-requirements/)
- [测试与正式分发概述](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases/)
- [注册设备分发](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices/)
- [TestFlight 分发](https://help.apple.com/xcode/mac/current/en.lproj/dev2539d985f.html)

## 未实现的功能
原生版本目前是项目采购账本，不是完整库存系统。库存查询、入库、出库、原生 DM 相机扫码和 N1 CoreBluetooth 打印尚未实现。References/N1-Web 为独立参考，不能当作原生功能验收通过。
