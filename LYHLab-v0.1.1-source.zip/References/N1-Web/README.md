# LYH LAB · N1 设备验证台

Private buildless HTTPS verification tool for one NIIMBOT N1. This is a printer diagnostic companion, not the inventory application.

## Scope

- Explicit user-initiated Web Bluetooth connection; require N1 model ID 3586, b1 task and 203 dpi before printing.
- Fixed 14×50 mm white gap-label profile; effective raster 96×400 px.
- One test label, human paper confirmation, camera/photo QR readback, then three sequential different labels.
- Device acknowledgement, human observations and decoded QR results are separate evidence.
- All operations serialized; no automatic print retries and no fabricated hardware results.
- Reports remain in the user's browser until explicitly copied/downloaded.

## Run and publish

No dependency installation or build required. Serve dist/ over HTTPS for Bluetooth and camera use. Hosting configuration is in .openai/hosting.json.

Validation commands: node --check dist/app.js and node scripts/check.mjs.

Use Android Chrome for initial testing. Ordinary iOS Safari / Firefox do not provide this Web Bluetooth path. Site access remains owner-private.

## Source

Vendor driver is pinned to iscarelli/niimbot-web-bluetooth commit 50801f40bc91a5bde782451c0e45b7e4e826f729, MIT; source receipt and license accompany the vendored file. Do not enable experimental fast/bundle/pipeline overrides. N1 jobs are automatically split into one-label jobs by the driver.

The user reported the complete original QR verification successful on 2026-11-16 (Asia/Shanghai). This is user-reported evidence for their printer and setup; it is not an official SDK certification or a claim about other firmware, media, or phones.

## Data Matrix trial

`/dm.html` adds a separate one-label Data Matrix ECC200 trial with its own report and local storage. The default payload is the representative identifier `LYH-U-00000001-06`. The symbol has 16×16 modules, 4 printer dots per module, and a 2-module quiet zone on each side, totaling 80×80 dots (about 10.0 mm at 203 dpi). This is a labelled example, not an allocated inventory record. The shorter P000001 QR/DM comparison assets are retained separately. It uses the same verified N1 raster-print profile.

The same-origin ZXing-WASM 3.1.7 reader is loaded only by the DM trial. It accepts valid Data Matrix results and matches both symbology and payload. Live camera frames and photos remain local. The reader serializes access to the WASM decoder across camera sessions and photo fallback. Source hashes and licenses are under `dist/vendor/zxing/`. Original QR verification uses its original jsQR decoder.

The user supplied a complete DM success report on 2026-11-16 03:57:01 (phone-local time), run fd782c74: N1（设备序列已移除） / 3586, 14×50 mm, payload LYH-U-00000001-06. The report records device acknowledgement, operator paper confirmation and successful photo decoding. This is user-reported evidence for that specific setup; no other browser is prepopulated with it.

The live-scan update adds an explicit rear-camera start/stop control, sequential frame decoding, and automatic camera release after a decoded Data Matrix or when the page goes to the background. Camera permission denial, cancellation and unsuccessful scans preserve existing successful evidence. The existing local-storage key is unchanged. Users can scan an existing label without Bluetooth or reprinting; without a matching acknowledged and paper-confirmed job, the read is kept separate and never becomes print evidence. Reports distinguish live_camera and photo. Live recognition on the user’s phone still requires their hands-on check; software lifecycle tests do not certify hardware camera performance.

Generate the DM raster and comparison asset with `scripts/generate-dm-label.py` using Pillow, numpy, and zxing-cpp 3.1.1. No user device is accessed by the generator.

The numbering formatter and parser are implemented in `dist/numbering.js`. The proposed backend allocation and inventory relationships are documented in `docs/identifier-scheme.md`; this diagnostic site does not implement an inventory database or allocator. `scripts/generate-formal-dm.py` creates the default long-identifier raster.
