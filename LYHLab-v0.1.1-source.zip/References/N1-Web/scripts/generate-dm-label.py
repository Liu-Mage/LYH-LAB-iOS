#!/usr/bin/env python3
"""Pixel-exact N1 QR / Data Matrix ECC200 comparison. No printer contacted."""
from pathlib import Path
import json
import shutil
import numpy as np
import zxingcpp
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parents[1] / 'dist' / 'labels'
SOURCE = OUT
PAYLOAD = 'P000001'
DPI = 203
REG = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
BOLD = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'

def font(size, bold=False):
    return ImageFont.truetype(BOLD if bold else REG, size, index=2)

def tight_text(draw, xy, text, f, fill, max_width=None):
    b=draw.textbbox((0,0),text,font=f)
    if max_width is not None:
        assert b[2]-b[0] <= max_width, (text,b,max_width)
    draw.text((xy[0]-b[0],xy[1]-b[1]),text,font=f,fill=fill)
    return b[2]-b[0], b[3]-b[1]

barcode = zxingcpp.create_barcode(PAYLOAD,zxingcpp.DataMatrix,force_square=True)
native = np.asarray(zxingcpp.write_barcode_to_image(barcode,scale=1,add_quiet_zones=False))
assert native.shape == (12,12), native.shape
assert set(np.unique(native)) <= {0,255}
symbol = Image.fromarray(native).convert('1')
# ECC200 symbol: 12x12 modules. Two quiet modules on each edge, at four dots/module.
module_dots, quiet_modules = 4, 2
matrix = Image.new('1',(16,16),1)
matrix.paste(symbol,(quiet_modules,quiet_modules))
matrix = matrix.resize((64,64),Image.Resampling.NEAREST)
landscape = Image.new('1',(400,96),1)
landscape.paste(matrix,(16,16))
d=ImageDraw.Draw(landscape);d.fontmode='1'
for xy,text,f in [((106,5),'电阻 10 kΩ',font(23,True)),((106,37),'0603 · 1%',font(20)),((106,69),PAYLOAD,font(19))]:
    tight_text(d,xy,text,f,0,282)
printed=landscape.transpose(Image.Transpose.ROTATE_270)
preview=Image.new('1',(400,112),1);preview.paste(landscape,(0,8))
printed.save(OUT/'dm-001-print.png',dpi=(DPI,DPI))
preview.save(OUT/'dm-001-preview.png',dpi=(DPI,DPI))
for suffix in ['print','preview']:
    shutil.copyfile(SOURCE/f'test-001-{suffix}.png',OUT/f'qr-n1-{suffix}.png')

checks=[]
for kind,fmt in [('qr',zxingcpp.QRCode),('dm',zxingcpp.DataMatrix)]:
    for suffix in ['print','preview']:
        path=OUT/f'dm-001-{suffix}.png' if kind == 'dm' else OUT/f'qr-n1-{suffix}.png'
        image=Image.open(path).convert('RGB')
        result=zxingcpp.read_barcode(image,formats=fmt)
        assert result and result.text == PAYLOAD, (path,result)
        checks.append({'file':path.name,'dimensions':list(image.size),'decoded':result.text,'format':str(result.format),'passed':True})

meta={
    'id':'n1-dm-p000001','payload':PAYLOAD,'format':'DataMatrix','standard':'ECC200',
    'title':'电阻 10 kΩ','spec':'0603 · 1%',
    'printer':'NIIMBOT N1','dpi':DPI,'paperWidthMm':14,'paperLengthMm':50,
    'printFile':'dm-001-print.png','previewFile':'dm-001-preview.png',
    'widthPx':96,'heightPx':400,'previewWidthPx':400,'previewHeightPx':112,
    'matrixWidthModules':12,'matrixHeightModules':12,
    'moduleDots':module_dots,'quietZoneModules':quiet_modules,
    'quietZoneDots':module_dots*quiet_modules,
    'symbolWithQuietZoneWidthDots':64,'symbolWithQuietZoneHeightDots':64,
    'symbolWithQuietZoneMm':round(64*25.4/DPI,4),
    'landscapeSymbolOriginPx':[16,16],
    'softwareDecodeVerified':True,'physicalPrintVerified':False,
    'generator':'zxing-cpp 3.1.1 / Zint-backed create_barcode',
    'decoder':'zxing-cpp 3.1.1',
    'notice':'测试编号，不是真实库存记录；PNG解码通过不代表手机扫码或实机打印已经通过。'
}
(OUT/'dm-meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
allmeta={'payload':PAYLOAD,'qr':{'format':'QR Code Model 2','version':1,'errorCorrection':'M','matrixModules':[21,21],'moduleDots':3,'quietZoneModules':4,'symbolWithQuietZoneDots':[87,87],'symbolWithQuietZoneMm':round(87*25.4/DPI,4),'userReportedPhysicalVerification':True,'source':'Exact copy of existing N1 test-001 PNG'},'dm':meta,'softwareDecodeChecks':checks,'previewScale':2,'comparisonFile':'dm-comparison.png'}
(OUT/'comparison-meta.json').write_text(json.dumps(allmeta,ensure_ascii=False,indent=2)+'\n')

# Mobile-oriented comparison poster. Label artwork is enlarged by exactly 2x
# using nearest-neighbour resampling; no code modules are stylized or altered.
W,H=1080,1500
img=Image.new('RGB',(W,H),'#f2f4ed');draw=ImageDraw.Draw(img)
green='#183f34';muted='#6a7b68';line='#dce5d5';pale='#e7efdf';amber='#8c6830'
draw.rounded_rectangle((56,44,112,100),radius=14,fill=green)
tight_text(draw,(69,58),'L',font(32,True),'#e8f3dc')
tight_text(draw,(131,60),'LYH LAB',font(27,True),green)
tight_text(draw,(56,128),'标准 QR 与 DM 码',font(51,True),green,968)
tight_text(draw,(58,199),'同一个测试编号 P000001 · 同样的 14 × 50 mm 标签',font(25),muted,968)

def pill(x,y,text,bg,fg):
    f=font(22,True);box=draw.textbbox((0,0),text,font=f);w=box[2]-box[0]+30
    draw.rounded_rectangle((x,y,x+w,y+42),radius=8,fill=bg)
    tight_text(draw,(x+15,y+10),text,f,fg)
    return w

def card(y,title,badge,kind,metrics,explanation,proven):
    draw.rounded_rectangle((56,y,1024,y+436),radius=22,fill='white',outline=line,width=2)
    tight_text(draw,(86,y+29),title,font(37,True),green,650)
    f=font(22,True);bb=draw.textbbox((0,0),badge,font=f);bw=bb[2]-bb[0]+30
    pill(994-bw,y+30,badge,'#e6f1da' if proven else '#fbf2df','#49703d' if proven else amber)
    label=Image.open(OUT/f'{kind}-n1-preview.png').convert('RGB').resize((800,224),Image.Resampling.NEAREST)
    draw.rounded_rectangle((85,y+99,995,y+335),radius=11,fill='#f4f6ef')
    img.paste(label,(140,y+105))
    tight_text(draw,(88,y+355),metrics,font(23),muted,904)
    tight_text(draw,(88,y+394),explanation,font(22),muted,904)

card(258,'标准 QR','用户已实机验证','qr','21 × 21 模块 · 3 点/模块 · 四边各留 4 模块白边','本次含白边 87 × 87 点，约 10.9 × 10.9 mm。',True)
card(718,'Data Matrix · ECC200','待实机验证','dm','12 × 12 模块 · 4 点/模块 · 四边各留 2 模块白边','本次含白边 64 × 64 点，约 8.0 × 8.0 mm。',False)
draw.rounded_rectangle((56,1184,1024,1412),radius=18,fill=pale)
tight_text(draw,(84,1209),'放大预览 · 需要分别验证扫码支持',font(29,True),green,912)
notes=[
    '两种 PNG 均已软件解码为 P000001。',
    'DM 本次更紧凑；手机扫码功能需要支持 Data Matrix。',
    '仅标准 QR 已收到用户实机通过反馈；DM 仍需试打与实扫。'
]
for i,t in enumerate(notes):tight_text(draw,(86,1261+i*43),t,font(23),muted,908)
tight_text(draw,(59,1440),'N1 / 203 dpi / 有效 96 点宽 · 样张均为测试数据',font(20),muted,962)
img.save(OUT/'dm-comparison.png')
print(json.dumps({'output':str(OUT),'checks':checks,'dm':{'matrix':'12x12','moduleDots':4,'quietZoneModules':2,'totalDots':'64x64','print':'96x400','preview':'400x112'},'comparison':[W,H]},ensure_ascii=False,indent=2))
