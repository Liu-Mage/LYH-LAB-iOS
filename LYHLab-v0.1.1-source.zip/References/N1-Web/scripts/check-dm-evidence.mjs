import assert from 'node:assert/strict';
import {createReadContext, readContextCurrent, classifyRead} from '../dist/dm-scan-evidence.js';

const code = 'LYH-U-00000001-06';
const result = [{format:'DataMatrix',text:code}];
const blank = () => ({sessionId:'run-a',job:null,scan:null});
let state = blank();
let context = createReadContext(state);
let read = classifyRead(state,context,result,'live_camera','test');
assert.equal(read.read.text,code);
assert.equal(read.read.verificationMatched,false);
assert.equal(read.verification,null,'Standalone scanning must not invent print evidence.');
assert.equal(state.job,null,'Reading must not create a job.');
assert.equal(state.scan,null,'Classification alone must not mutate saved evidence.');

for (const job of [
  {id:'job-a',payload:code,acknowledged:false,paper:true},
  {id:'job-a',payload:code,acknowledged:true,paper:null},
  {id:'job-a',payload:code,acknowledged:true,paper:false}
]) {
  state = {...blank(),job};
  read = classifyRead(state,createReadContext(state),result,'photo','test');
  assert.equal(read.verification,null,'Both device acknowledgement and paper confirmation are required.');
}

state = {...blank(),job:{id:'job-a',payload:code,acknowledged:true,paper:true}};
context = createReadContext(state);
read = classifyRead(state,context,result,'live_camera','test');
assert.equal(read.verification.text,code);
assert.equal(read.verification.source,'live_camera');
state.scan = {...read.verification,source:'photo'};
const previous = structuredClone(state.scan);
assert.equal(classifyRead(state,context,[],'live_camera','test'),null);
assert.equal(classifyRead(state,context,[{format:'QRCode',text:code}],'photo','test'),null);
assert.equal(classifyRead(state,context,[{format:'DataMatrix',text:'another-code'}],'live_camera','test').verification,null);
assert.deepEqual(state.scan,previous,'A failed or unmatched read must preserve prior successful evidence.');

assert.equal(readContextCurrent({...state,sessionId:'run-b'},context),false);
assert.equal(classifyRead({...state,sessionId:'run-b'},context,result,'live_camera','test'),null);
assert.equal(classifyRead({...state,job:{...state.job,id:'job-b'}},context,result,'live_camera','test'),null);
assert.equal(classifyRead({...state,job:null},context,result,'live_camera','test'),null);
assert.equal(classifyRead({...state,job:{...state.job,paper:false}},context,result,'live_camera','test').verification,null);
assert.equal(classifyRead(state,context,[{format:'DataMatrix',text:'other'},...result],'photo','test').verification.text,code);
console.log('PASS: standalone reads, acknowledgement/paper gates, source attribution, old-evidence preservation, stale session/job rejection.');

// The camera and photo path share one WASM instance. Exercise its queue with a
// controlled asynchronous reader, including a rejected decode followed by recovery.
let inFlight = 0, peak = 0, calls = 0;
globalThis.ZXingWASM = {
  prepareZXingModule: async () => undefined,
  readBarcodes: async () => {
    const call = ++calls;
    peak = Math.max(peak,++inFlight);
    await new Promise(resolve => setTimeout(resolve,5));
    --inFlight;
    if (call === 2) throw new Error('expected decoder failure');
    return [
      {isValid:true,symbology:'DataMatrix',text:code},
      {isValid:true,symbology:'QRCode',text:code},
      {isValid:false,symbology:'DataMatrix',text:code}
    ];
  }
};
const {decodeDataMatrix} = await import('../dist/dm-decoder.js');
const pixels = {width:1,height:1,data:new Uint8ClampedArray(4)};
const outcomes = await Promise.allSettled([decodeDataMatrix(pixels),decodeDataMatrix(pixels),decodeDataMatrix(pixels)]);
assert.equal(peak,1,'Camera and photo decodes must never overlap.');
assert.deepEqual(outcomes.map(x=>x.status),['fulfilled','rejected','fulfilled']);
assert.deepEqual(outcomes[2].value,result,'A decoder rejection must not poison the queue.');
console.log('PASS: shared decoder serialization, symbology filtering and failure recovery.');
