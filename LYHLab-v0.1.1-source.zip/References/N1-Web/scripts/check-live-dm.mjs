// Lifecycle checks use the real class with fake camera/video/canvas objects.
// No browser, hardware, network, or recognition result is simulated in production.
import assert from 'node:assert/strict';
import { LiveDMScanner } from '../dist/live-dm-scanner.js';

const native = {setTimeout:globalThis.setTimeout,clearTimeout:globalThis.clearTimeout,document:globalThis.document};
const hadDocument = Object.hasOwn(globalThis,'document');
const timers = new Map();
let timerId = 0, checks = 0;
const flush = () => new Promise(resolve => setImmediate(resolve));
function deferred() {
  let resolve, reject;
  const promise = new Promise((r,j) => {resolve=r;reject=j;});
  return {promise,resolve,reject};
}
class FakeTrack extends EventTarget {
  constructor() {super();this.readyState='live';this.stops=0;}
  stop() {this.stops++;this.readyState='ended';}
}
class FakeStream extends EventTarget {
  constructor(count=1) {super();this.tracks=Array.from({length:count},()=>new FakeTrack());}
  getTracks() {return this.tracks;}
  getVideoTracks() {return this.tracks;}
}
class FakeVideo extends EventTarget {
  constructor(plays=[]) {
    super();this.srcObject=null;this.readyState=2;this.videoWidth=1920;this.videoHeight=1080;
    this.plays=plays;this.pauses=0;this.attributes=new Map();
  }
  setAttribute(name,value) {this.attributes.set(name,value);}
  play() {return this.plays.shift() || Promise.resolve();}
  pause() {this.pauses++;}
}
function assertStopped(stream) {for(const track of stream.getTracks()) assert.equal(track.stops,1);}
function runNextTimer() {
  const next=timers.entries().next();
  if(next.done) return false;
  const [id,{fn}]=next.value;timers.delete(id);fn();return true;
}
async function check(name,run) {
  assert.equal(timers.size,0,name + ': prior test leaked a timer');
  await run();
  assert.equal(timers.size,0,name + ': stopped sessions leaked a timer');
  checks++;
}

globalThis.setTimeout=(fn,delay)=>{timers.set(++timerId,{fn,delay});return timerId;};
globalThis.clearTimeout=id=>timers.delete(id);
globalThis.document={createElement(tag){
  assert.equal(tag,'canvas');
  return {width:0,height:0,getContext(kind){
    assert.equal(kind,'2d');
    return {drawImage(){},getImageData(x,y,width,height){
      return {width,height,data:new Uint8ClampedArray(width*height*4)};
    }};
  }};
}};

try {
  await check('late permission result',async()=>{
    const permission=deferred(),video=new FakeVideo(),states=[],errors=[];
    const reader=new LiveDMScanner({video,decode:async()=>[],getUserMedia:()=>permission.promise,onState:s=>states.push(s),onError:e=>errors.push(e)});
    const opening=reader.start({job:'cancelled'});
    assert.equal(reader.state,'opening');assert.equal(reader.active,true);
    reader.stop();const stoppedStates=[...states];
    const lateStream=new FakeStream(2);permission.resolve(lateStream);
    assert.equal(await opening,false);assertStopped(lateStream);
    assert.equal(video.srcObject,null);assert.equal(reader.state,'idle');
    assert.deepEqual(states,stoppedStates);assert.equal(errors.length,0);
  });

  await check('late permission cannot affect new session',async()=>{
    const first=deferred(),second=deferred(),video=new FakeVideo(),states=[],errors=[];let requests=0;
    const reader=new LiveDMScanner({video,decode:async()=>[],getUserMedia:()=>++requests===1?first.promise:second.promise,onState:s=>states.push(s),onError:e=>errors.push(e)});
    const oldStart=reader.start({job:'old'});reader.stop();const newStart=reader.start({job:'new'});
    const currentStream=new FakeStream();second.resolve(currentStream);assert.equal(await newStart,true);
    const runningStates=[...states],lateStream=new FakeStream();first.resolve(lateStream);
    assert.equal(await oldStart,false);assertStopped(lateStream);
    assert.equal(currentStream.tracks[0].stops,0);assert.equal(video.srcObject,currentStream);
    assert.equal(reader.state,'running');assert.deepEqual(states,runningStates);assert.equal(errors.length,0);
    reader.stop();assertStopped(currentStream);assert.equal(video.srcObject,null);
  });

  await check('late video play cannot affect new session',async()=>{
    const latePlay=deferred(),video=new FakeVideo([latePlay.promise]),streams=[new FakeStream(),new FakeStream()];let requests=0;
    const reader=new LiveDMScanner({video,decode:async()=>[],getUserMedia:async()=>streams[requests++]});
    const oldStart=reader.start({job:'old-play'});await flush();assert.equal(video.srcObject,streams[0]);
    reader.stop();assert.equal(await reader.start({job:'new-play'}),true);
    latePlay.resolve();assert.equal(await oldStart,false);
    assert.equal(reader.state,'running');assert.equal(video.srcObject,streams[1]);assertStopped(streams[0]);
    reader.stop();assertStopped(streams[1]);
  });

  await check('consecutive frames never overlap',async()=>{
    const video=new FakeVideo(),stream=new FakeStream(),first=deferred(),second=deferred();
    let calls=0,active=0,maxActive=0;
    const reader=new LiveDMScanner({video,getUserMedia:async()=>stream,decode:()=>{
      calls++;active++;maxActive=Math.max(maxActive,active);
      return (calls===1?first.promise:second.promise).finally(()=>{active--;});
    }});
    await reader.start({job:'frames'});assert.equal(runNextTimer(),true);await flush();
    assert.equal(calls,1);assert.equal(active,1);assert.equal(timers.size,0,'next frame must wait for decode completion');
    // Even an unexpected duplicate frame invocation cannot start a second decoder.
    await reader._readFrame(reader._session);assert.equal(calls,1);
    first.resolve([]);await flush();assert.equal(active,0);assert.equal(runNextTimer(),true);await flush();
    assert.equal(calls,2);assert.equal(active,1);assert.equal(maxActive,1);
    reader.stop();second.resolve([]);await flush();assert.equal(active,0);assertStopped(stream);
  });

  await check('old decode result ignored and success releases current stream',async()=>{
    const pending=deferred(),video=new FakeVideo(),streams=[new FakeStream(),new FakeStream()],hits=[];let requests=0,calls=0;
    const reader=new LiveDMScanner({video,getUserMedia:async()=>streams[requests++],decode:()=>++calls===1?pending.promise:Promise.resolve([{format:'DataMatrix',text:'NEW'}]),onResults:(results,context)=>{hits.push({results,context});return true;}});
    await reader.start({job:'old'});const oldFrame=reader._readFrame(reader._session);await flush();
    reader.stop();const currentContext={job:'new'};await reader.start(currentContext);
    await reader._readFrame(reader._session);assert.equal(calls,1,'new session must wait for old decode to settle');
    pending.resolve([{format:'DataMatrix',text:'OLD'}]);await oldFrame;
    assert.equal(hits.length,0);assert.equal(reader.state,'running');assert.equal(video.srcObject,streams[1]);
    await reader._readFrame(reader._session);
    assert.equal(hits.length,1);assert.equal(hits[0].context,currentContext);assert.equal(hits[0].results[0].text,'NEW');
    assert.equal(reader.state,'idle');assert.equal(reader.active,false);assert.equal(video.srcObject,null);
    assertStopped(streams[0]);assertStopped(streams[1]);
  });

  await check('old decode failure cannot overwrite new session',async()=>{
    const pending=deferred(),video=new FakeVideo(),streams=[new FakeStream(),new FakeStream()],errors=[],states=[],statuses=[];let requests=0,calls=0;
    const reader=new LiveDMScanner({video,getUserMedia:async()=>streams[requests++],decode:()=>++calls===1?pending.promise:Promise.resolve([]),onError:e=>errors.push(e),onState:s=>states.push(s),onStatus:s=>statuses.push(s)});
    await reader.start({job:'old-error'});const oldFrame=reader._readFrame(reader._session);await flush();
    reader.stop();await reader.start({job:'new-healthy'});const currentStates=[...states],currentStatuses=[...statuses];
    pending.reject(new Error('old session decoder failure'));await oldFrame;
    assert.equal(reader.state,'running');assert.equal(video.srcObject,streams[1]);assert.equal(errors.length,0);
    assert.deepEqual(states,currentStates);assert.deepEqual(statuses,currentStatuses);
    await reader._readFrame(reader._session);assert.equal(calls,2);reader.stop();assertStopped(streams[1]);
  });

  await check('camera ended stops and reports a retryable failure',async()=>{
    const video=new FakeVideo(),stream=new FakeStream(),errors=[],statuses=[];
    const reader=new LiveDMScanner({video,decode:async()=>[],getUserMedia:async()=>stream,onError:e=>errors.push(e),onStatus:s=>statuses.push(s)});
    await reader.start({job:'ended'});stream.tracks[0].dispatchEvent(new Event('ended'));
    assert.equal(reader.state,'idle');assert.equal(video.srcObject,null);assertStopped(stream);assert.equal(errors.length,1);
    assert.match(statuses.at(-1),/重新打开/);
    stream.tracks[0].dispatchEvent(new Event('ended'));assert.equal(errors.length,1,'stopped listeners must be removed');
  });

  await check('current decoder failure releases resources',async()=>{
    const video=new FakeVideo(),stream=new FakeStream(),errors=[],failure=new Error('decoder unavailable');
    const reader=new LiveDMScanner({video,decode:async()=>{throw failure;},getUserMedia:async()=>stream,onError:e=>errors.push(e)});
    await reader.start({job:'decode-error'});await reader._readFrame(reader._session);
    assert.equal(reader.state,'idle');assert.equal(video.srcObject,null);assertStopped(stream);assert.equal(errors[0],failure);
  });

  console.log(`PASS: ${checks} live DM lifecycle checks; delayed camera/play, exclusive frames, stale result/error isolation, success/ended/error cleanup.`);
} finally {
  globalThis.setTimeout=native.setTimeout;globalThis.clearTimeout=native.clearTimeout;
  if(hadDocument) globalThis.document=native.document;else delete globalThis.document;
}
