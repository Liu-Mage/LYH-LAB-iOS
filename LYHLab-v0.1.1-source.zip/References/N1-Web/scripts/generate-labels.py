#!/usr/bin/env python3
"""Generate pixel-exact NIIMBOT N1 verification labels.

Dependencies: Pillow, qrcode==8.2, zxing-cpp==3.1.1.
Run from any directory; assets are written to ../dist/labels.
No physical printer is contacted. Decoder checks validate the PNGs only.
"""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
import qrcode
import zxingcpp


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist" / "labels"
REGULAR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
DPI = 203
HEAD_WIDTH_PX = 96
LENGTH_PX = 400
PAPER_WIDTH_PX = 112


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(BOLD if bold else REGULAR, size, index=2)


def draw_text(draw: ImageDraw.ImageDraw, xy, text, text_font, *, max_width=None):
    # Font rendering in one-bit mode keeps glyphs crisp at printer resolution.
    draw.fontmode = "1"
    box = draw.textbbox((0, 0), text, font=text_font)
    w, h = box[2] - box[0], box[3] - box[1]
    if max_width is not None:
        assert w <= max_width, (text, w, max_width)
    x, y = xy
    assert x >= 0 and y >= 0
    assert x + w <= LENGTH_PX and y + h <= HEAD_WIDTH_PX, (text, xy, w, h)
    draw.text((x - box[0], y - box[1]), text, font=text_font, fill=0)
    return {"text": text, "x": x, "y": y, "width": w, "height": h}


def save_pair(horizontal: Image.Image, asset_id: str):
    assert horizontal.size == (LENGTH_PX, HEAD_WIDTH_PX)
    assert set(horizontal.convert("L").getdata()) <= {0, 255}
    printable = horizontal.transpose(Image.Transpose.ROTATE_270)
    assert printable.size == (HEAD_WIDTH_PX, LENGTH_PX)
    printable.save(OUT / f"{asset_id}-print.png", dpi=(DPI, DPI))
    preview = Image.new("1", (LENGTH_PX, PAPER_WIDTH_PX), 1)
    preview.paste(horizontal, (0, 8))
    preview.save(OUT / f"{asset_id}-preview.png", dpi=(DPI, DPI))
    return printable, preview


def create_label(number: int, title: str, spec: str):
    payload = f"P{number:06d}"
    asset_id = f"test-{number:03d}"
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M,
                       box_size=3, border=4)
    qr.add_data(payload, optimize=0)
    qr.make(fit=False)
    qr_image = qr.make_image(fill_color="black", back_color="white").convert("1")
    assert qr_image.size == (87, 87)
    # Four-module (12 px) quiet zone exists in the QR image itself.
    horizontal = Image.new("1", (LENGTH_PX, HEAD_WIDTH_PX), 1)
    horizontal.paste(qr_image, (4, 4))
    draw = ImageDraw.Draw(horizontal)
    bounds = [
        draw_text(draw, (106, 5), title, font(23, True), max_width=282),
        draw_text(draw, (106, 37), spec, font(20), max_width=282),
        draw_text(draw, (106, 69), payload, font(19), max_width=282),
    ]
    printable, preview = save_pair(horizontal, asset_id)
    decoded_print = zxingcpp.read_barcode(printable.convert("RGB"))
    decoded_preview = zxingcpp.read_barcode(preview.convert("RGB"))
    assert decoded_print and decoded_print.text == payload
    assert decoded_preview and decoded_preview.text == payload
    print(f"PASS {asset_id}: {payload}; print=96x400 preview=400x112; PNG decoded in both orientations")
    return {
        "id": asset_id,
        "payload": payload,
        "title": title,
        "spec": spec,
        "printSrc": f"/labels/{asset_id}-print.png",
        "previewSrc": f"/labels/{asset_id}-preview.png",
        "widthPx": HEAD_WIDTH_PX,
        "heightPx": LENGTH_PX,
        "previewWidthPx": LENGTH_PX,
        "previewHeightPx": PAPER_WIDTH_PX,
        "qrVersion": 1,
        "qrErrorCorrection": "M",
        "qrModulePx": 3,
        "qrQuietZoneModules": 4,
        "qrOuterSizePx": 87,
        "textBounds": bounds,
        "softwareDecodeVerified": True,
        "physicalPrintVerified": False,
    }


def create_calibration():
    horizontal = Image.new("1", (LENGTH_PX, HEAD_WIDTH_PX), 1)
    draw = ImageDraw.Draw(horizontal)
    draw_text(draw, (12, 5), "N1 · 10 mm 标尺", font(22, True))
    # Tick centre-to-centre distance is 80 printer dots, or 10.00985 mm
    # at the nominal 203 dpi. This is the intended 8 dots/mm approximation.
    x0, x1, y = 150, 230, 53
    draw.line((x0, y, x1, y), fill=0, width=1)
    for i in range(11):
        x = x0 + i * 8
        half_height = 9 if i in (0, 5, 10) else 4
        draw.line((x, y - half_height, x, y + half_height), fill=0, width=1)
    draw_text(draw, (143, 70), "0", font(16))
    draw_text(draw, (217, 70), "10", font(16))
    printable, preview = save_pair(horizontal, "calibration")
    assert zxingcpp.read_barcode(printable.convert("RGB")) is None
    return {
        "id": "calibration",
        "payload": None,
        "title": "10 mm 标尺",
        "spec": "测量两端最长刻线的中心距离，约 10 mm",
        "printSrc": "/labels/calibration-print.png",
        "previewSrc": "/labels/calibration-preview.png",
        "widthPx": HEAD_WIDTH_PX,
        "heightPx": LENGTH_PX,
        "rulerLengthPx": 80,
        "nominalRulerLengthMm": 80 * 25.4 / DPI,
        "physicalPrintVerified": False,
    }


def create_contact_sheet(labels):
    sheet = Image.new("RGB", (960, 1200), "#eef2f7")
    draw = ImageDraw.Draw(sheet)
    header = font(32, True)
    sub = font(20)
    draw.text((48, 28), "N1 测试标签 · 放大预览", font=header, fill="#15213a")
    draw.text((48, 78), "14 × 50 mm 纸张 / 12 mm 有效打印宽度 / 测试数据", font=sub, fill="#56647c")
    for index, label in enumerate(labels):
        y = 140 + index * 258
        draw.text((50, y), f"{index + 1:02d}   {label['payload']}", font=font(20, True), fill="#32445b")
        img = Image.open(OUT / f"{label['id']}-preview.png").convert("RGB")
        img = img.resize((800, 224), Image.Resampling.NEAREST)
        sheet.paste(img, (80, y + 30))
    sheet.save(OUT / "contact-sheet.png")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    labels = [
        create_label(1, "电阻 10 kΩ", "0603 · 1%"),
        create_label(2, "电容 100 nF", "0603 · 50 V"),
        create_label(3, "ESP32-S3", "WROOM-1U"),
        create_label(4, "M3×8 螺丝", "测试样张"),
    ]
    calibration = create_calibration()
    manifest = {
        "schemaVersion": 1,
        "printer": {
            "model": "NIIMBOT N1",
            "dpi": DPI,
            "effectiveWidthPx": HEAD_WIDTH_PX,
            "paperWidthMm": 14,
            "paperLengthMm": 50,
            "printWidthPx": HEAD_WIDTH_PX,
            "printHeightPx": LENGTH_PX,
            "previewWidthPx": LENGTH_PX,
            "previewHeightPx": PAPER_WIDTH_PX,
        },
        "labels": labels,
        "calibration": calibration,
        "notice": "仅测试数据；PNG 解码通过不代表实机打印通过。预览不可用作原尺寸打印源。",
        "generator": {"qrcode": "8.2", "decoder": "zxing-cpp 3.1.1"},
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    create_contact_sheet(labels)
    print(f"Saved {len(labels)} test labels, calibration and manifest to {OUT}")


if __name__ == "__main__":
    main()
