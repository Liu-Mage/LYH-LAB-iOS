#!/usr/bin/env python3
"""Create a representative LYH inventory-unit DM test label; no record is allocated."""
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import zxingcpp

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist' / 'labels'
payload = json.loads((ROOT / 'dist' / 'numbering-examples.json').read_text())['examples']['U']
barcode = zxingcpp.create_barcode(payload, zxingcpp.DataMatrix, force_square=True)
matrix = np.asarray(zxingcpp.write_barcode_to_image(barcode, scale=1, add_quiet_zones=False))
assert matrix.shape == (16,16), matrix.shape
module, quiet, dpi = 4, 2, 203
square = Image.new('1', (20,20), 1)
square.paste(Image.fromarray(matrix).convert('1'), (quiet,quiet))
square = square.resize((80,80), Image.Resampling.NEAREST)
landscape = Image.new('1',(400,96),1)
landscape.paste(square,(8,8))
draw = ImageDraw.Draw(landscape); draw.fontmode='1'
for x,y,text,size,bold in [(106,5,'电阻 10 kΩ',23,True),(106,37,'0603 · 1% · 示例',18,False),(106,69,payload,17,False)]:
    font = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-'+('Bold' if bold else 'Regular')+'.ttc', size, index=2)
    b=draw.textbbox((0,0),text,font=font)
    assert x+b[2]-b[0] <= 396 and y+b[3]-b[1] <= 96
    draw.text((x-b[0],y-b[1]),text,font=font,fill=0)
printed = landscape.transpose(Image.Transpose.ROTATE_270)
preview = Image.new('1',(400,112),1); preview.paste(landscape,(0,8))
for suffix,img in [('print',printed),('preview',preview)]:
    assert set(np.unique(np.asarray(img.convert('L')))) <= {0,255}
    decoded=zxingcpp.read_barcode(img.convert('RGB'),formats=zxingcpp.DataMatrix)
    assert decoded and decoded.text == payload
    img.save(OUT/f'dm-formal-{suffix}.png',dpi=(dpi,dpi))
# Check the existing N1 profile's one-dot vertical offset too.
shifted = Image.new('1', printed.size, 1); shifted.paste(printed,(0,-1))
assert zxingcpp.read_barcode(shifted.convert('RGB'),formats=zxingcpp.DataMatrix).text == payload
meta={'payload':payload,'format':'DataMatrix','standard':'ECC200','sampleOnly':True,'widthPx':96,'heightPx':400,'modules':[16,16],'moduleDots':4,'quietZoneModules':2,'symbolWithQuietZoneDots':80,'symbolWithQuietZoneMm':80*25.4/dpi,'printFile':'dm-formal-print.png','previewFile':'dm-formal-preview.png','softwareDecodeVerified':True,'physicalPrintVerified':False}
(OUT/'dm-formal-meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(meta,ensure_ascii=False))
