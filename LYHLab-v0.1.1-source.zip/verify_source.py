#!/usr/bin/env python3
"""Linux structural guardrails only. Not a Swift compiler or iOS integration test."""
from pathlib import Path
import re, xml.etree.ElementTree as ET, shutil
p=Path(__file__).resolve().parent
api=(p/'LYHLab/API.swift').read_text()
ui=(p/'LYHLab/LYHLabApp.swift').read_text()
project=(p/'LYHLab.xcodeproj/project.pbxproj').read_text()
ET.parse(p/'LYHLab.xcodeproj/xcshareddata/xcschemes/LYHLab.xcscheme')
ids=re.findall(r'^([A-F0-9]{24}) = ',project,re.M)
assert len(ids)==len(set(ids))
refs=re.findall(r'\b[A-F0-9]{24}\b',project)
assert set(refs)==set(ids)
for f in ['API.swift','Models.swift','LYHLabApp.swift']:
    assert (p/'LYHLab'/f).exists() and f in project
for path in ['/api/me','/api/login','/api/logout','/api/admin/purchases']:
    assert path in api
assert '/api/admin/purchases/export.csv?project_id=' in ui
assert '/api/admin/purchases?project_id=' in api
assert '/api/admin/purchase-projects' in api
assert 'body["project_id"] = projectID' in ui
assert '"project": project' not in ui
assert '项目采购管理' in ui
assert 'import Combine' in api
assert 'URLSessionConfiguration.ephemeral' in api and 'c.httpCookieStorage = nil' in api
assert 'c.httpShouldSetCookies = false' in api and 'c.urlCache = nil' in api
assert 'completionHandler(nil)' in api
assert 'auth.isSecure' in api or '$0.isSecure' in api
assert '"X-CSRF-Token"' in api and '"Cookie"' in api
assert 'NSAllowsArbitraryLoads' not in project and 'NSAppTransportSecurity' not in project
for bad in ['URLCredential(', 'UserDefaults', 'SecItemAdd', 'serverTrust', 'WKWebView', 'http://']:
    assert bad not in api+ui+project, bad
assert '"archived"' not in ui
assert 'NSNull()' in ui and 'parseCents(amount)' in ui
assert 'uncertain' in ui and '关闭并刷新核对结果' in ui
print('PASS source/project references, scheme XML, API paths, TLS/auth guards, uncertainty/unknown-value handling')
print('NOT RUN Swift compilation, simulator/device, live login or mutation, IPA signing')
print('swift available:',bool(shutil.which('swift')),'xcodebuild available:',bool(shutil.which('xcodebuild')))

assert "normalizedServerOrigin(server)" in api
assert "static let origin" not in api
assert "api.login(server: server" in ui
assert "parts.user == nil" in (p/"LYHLab/Models.swift").read_text()
