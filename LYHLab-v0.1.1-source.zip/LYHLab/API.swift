import Foundation
import Combine

// No disk cookie store, Keychain, password persistence or TLS exception.
// Refuse redirects so credentials can never follow a server redirect elsewhere.
final class NoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
@MainActor final class API: ObservableObject {
    private(set) var origin = ""
    @Published var account: Account?
    private var csrf: String?
    private var cookie: String?
    private let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.httpCookieStorage = nil
        c.httpShouldSetCookies = false
        c.urlCache = nil
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.timeoutIntervalForRequest = 25
        return URLSession(configuration: c, delegate: NoRedirect(), delegateQueue: nil)
    }()
    func clear() { account = nil; csrf = nil; cookie = nil }
    func request(_ path: String, method: String = "GET", body: [String: Any]? = nil) async throws -> Data {
        guard path.hasPrefix("/api/"), let url = URL(string: origin + path), url.scheme == "https" else {
            throw APIError(text: "服务器必须使用有效 HTTPS")
        }
        var r = URLRequest(url: url)
        r.httpMethod = method
        r.setValue(origin, forHTTPHeaderField: "Origin")
        r.setValue(cookie, forHTTPHeaderField: "Cookie")
        if let body = body {
            r.setValue("application/json", forHTTPHeaderField: "Content-Type")
            r.setValue(csrf, forHTTPHeaderField: "X-CSRF-Token")
            r.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        let data: Data; let response: URLResponse
        do { (data, response) = try await session.data(for: r) }
        catch {
            throw APIError(text: method == "GET" ? "连接失败，请检查网络及服务器 HTTPS 证书。" : "请求未确认成功。请刷新列表检查结果，再决定是否重试，避免重复记录。")
        }
        guard let http = response as? HTTPURLResponse else { throw APIError(text: "无效响应") }
        if http.statusCode == 401 { clear() }
        guard (200..<300).contains(http.statusCode) else {
            let error = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw APIError(text: error?["error"] as? String ?? "服务器返回 \(http.statusCode)")
        }
        if path == "/api/login", let header = http.value(forHTTPHeaderField: "Set-Cookie") {
            let cookies = HTTPCookie.cookies(withResponseHeaderFields: ["Set-Cookie": header], for: url)
            guard let auth = cookies.first(where: { $0.name == "hp_session" && $0.isSecure }) else {
                throw APIError(text: "服务器未提供安全登录会话")
            }
            cookie = "hp_session=" + auth.value
        }
        return data
    }
    func login(server: String, username: String, password: String) async throws {
        clear()
        origin = try normalizedServerOrigin(server)
        var accepted = false
        defer { if !accepted { clear() } }
        let data = try await request("/api/login", method: "POST", body: ["username": username, "password": password])
        let result = try JSONDecoder().decode(SessionResult.self, from: data)
        csrf = result.csrf_token
        guard let user = result.user, user.role == "admin", csrf != nil, cookie != nil else {
            try? await logout()
            throw APIError(text: "该应用仅供管理员使用")
        }
        // Verify the same server-side session before displaying private data.
        let me = try JSONDecoder().decode(SessionResult.self, from: await request("/api/me"))
        guard me.user?.role == "admin" else { clear(); throw APIError(text: "管理员会话无效") }
        account = user
        accepted = true
    }
    func logout() async throws {
        defer { clear() }
        _ = try await request("/api/logout", method: "POST", body: [:])
    }
    func projects() async throws -> [PurchaseProject] {
        try JSONDecoder().decode(ProjectList.self, from: await request("/api/admin/purchase-projects")).projects
    }
    func load(projectID: Int) async throws -> Ledger {
        try JSONDecoder().decode(Ledger.self, from: await request("/api/admin/purchases?project_id=\(projectID)"))
    }
    func save(id: Int?, body: [String: Any]) async throws {
        _ = try await request("/api/admin/purchases" + (id.map { "/\($0)" } ?? ""), method: id == nil ? "POST" : "PATCH", body: body)
    }
}
