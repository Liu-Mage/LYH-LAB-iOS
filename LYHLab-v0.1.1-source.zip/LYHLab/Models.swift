import Foundation

struct Account: Decodable { let id: Int; let username: String; let role: String }
struct SessionResult: Decodable { let user: Account?; let csrf_token: String? }
struct Purchase: Decodable, Identifiable {
    let id: Int
    let name: String
    let quantity: Int?
    let amount_cents: Int?
    let status: String
    let project: String
    let notes: String
    let source_ref: String?
    let updated_at: String
}
struct Ledger: Decodable {
    let items: [Purchase]
    let summary: Summary
    struct Summary: Decodable {
        let planned_count: Int; let purchased_count: Int
        let actual_cents: Int; let unknown_count: Int
    }
}
struct APIError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}
func yuan(_ cents: Int) -> String { String(format: "%d.%02d", cents / 100, cents % 100) }
func parseCents(_ input: String) throws -> Int? {
    let value = input.trimmingCharacters(in: .whitespacesAndNewlines)
    if value.isEmpty { return nil }
    guard value.range(of: #"^[0-9]+(\.[0-9]{1,2})?$"#, options: .regularExpression) != nil else {
        throw APIError(text: "金额请输入最多两位小数的非负数字")
    }
    let parts = value.split(separator: ".")
    guard let whole = Int(parts[0]), whole <= 1_000_000 else { throw APIError(text: "金额超出范围") }
    let fraction = parts.count == 2 ? Int(String(parts[1]).padding(toLength: 2, withPad: "0", startingAt: 0))! : 0
    let cents = whole * 100 + fraction
    guard cents <= 100_000_000 else { throw APIError(text: "金额超出范围") }
    return cents
}

struct PurchaseProject: Decodable, Identifiable {
    let id: Int
    let name: String
}
struct ProjectList: Decodable { let projects: [PurchaseProject] }

// A server address is entered by the owner, never bundled with public source.
// Only a bare HTTPS origin is accepted; reject embedded credentials and URL paths.
func normalizedServerOrigin(_ input: String) throws -> String {
    let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !text.isEmpty, !text.contains("\\"), !text.contains("%"),
          !text.unicodeScalars.contains(where: { CharacterSet.whitespacesAndNewlines.contains($0) }),
          var parts = URLComponents(string: text),
          parts.scheme?.lowercased() == "https",
          let host = parts.host, !host.isEmpty,
          parts.user == nil, parts.password == nil,
          parts.query == nil, parts.fragment == nil,
          parts.path.isEmpty || parts.path == "/",
          parts.port == nil || (1...65535).contains(parts.port!),
          parts.url != nil else {
        throw APIError(text: "请输入完整 HTTPS 网站地址，不含账号、路径或查询参数。")
    }
    parts.scheme = "https"
    parts.host = host.lowercased()
    parts.path = ""
    guard let normalized = parts.string else { throw APIError(text: "网站地址无效") }
    return normalized
}
