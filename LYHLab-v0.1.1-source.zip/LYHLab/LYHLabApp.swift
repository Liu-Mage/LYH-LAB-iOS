import SwiftUI
import UniformTypeIdentifiers

@main struct LYHLabApp: App {
    @StateObject private var api = API()
    var body: some Scene {
        WindowGroup {
            Group {
                if api.account != nil { LedgerView() } else { LoginView() }
            }.environmentObject(api).tint(LabTheme.green).preferredColorScheme(.light)
        }
    }
}
enum LabTheme {
    static let ink = Color(red: 20/255.0, green: 45/255.0, blue: 55/255.0)
    static let green = Color(red: 8/255.0, green: 125/255.0, blue: 100/255.0)
    static let muted = Color(red: 86/255.0, green: 106/255.0, blue: 114/255.0)
    static let background = Color(red: 243/255.0, green: 246/255.0, blue: 245/255.0)
    static let pale = Color(red: 232/255.0, green: 242/255.0, blue: 238/255.0)
}
struct LabCard: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(.white, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}
extension View { func labCard() -> some View { modifier(LabCard()) } }
struct LabBrand: View {
    var body: some View {
        Text("LYH LAB  /  项目工作台").font(.caption.weight(.bold)).tracking(1.5).foregroundStyle(LabTheme.green)
            .accessibilityLabel("LYH LAB 项目工作台")
    }
}
struct LabPrimary: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline).frame(maxWidth: .infinity).frame(minHeight: 52)
            .foregroundStyle(.white).background(LabTheme.green.opacity(configuration.isPressed ? 0.8 : 1), in: RoundedRectangle(cornerRadius: 14))
    }
}
struct LoginView: View {
    @EnvironmentObject var api: API
    @State private var server = ""
    @State private var username = ""
    @State private var password = ""
    @State private var busy = false
    @State private var error = ""
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    LabBrand()
                    VStack(alignment: .leading, spacing: 10) {
                        Text("项目采购管理").font(.largeTitle.bold()).foregroundStyle(LabTheme.ink)
                        Text("把每个项目的采购与花费，记清楚。每次只需要几步。").foregroundStyle(LabTheme.muted)
                    }
                    VStack(alignment: .leading, spacing: 16) {
                        Text("欢迎回来").font(.title2.bold())
                        Text("使用网站管理员账号，继续同一份项目记录。").font(.subheadline).foregroundStyle(LabTheme.muted)
                        VStack(alignment: .leading, spacing: 8) {
                            Text("网站地址").font(.subheadline.weight(.medium))
                            TextField("https://你的站点", text: $server).keyboardType(.URL)
                                .textInputAutocapitalization(.never).autocorrectionDisabled()
                                .disabled(busy)
                                .padding(14).background(LabTheme.background, in: RoundedRectangle(cornerRadius: 12))
                            Text("请核对地址后再登录；账号密码会发送到此网站。").font(.caption).foregroundStyle(LabTheme.muted)
                        }
                        VStack(alignment: .leading, spacing: 8) {
                            Text("管理员账号").font(.subheadline.weight(.medium))
                            TextField("输入账号", text: $username).textContentType(.username)
                                .textInputAutocapitalization(.never).autocorrectionDisabled()
                                .padding(14).background(LabTheme.background, in: RoundedRectangle(cornerRadius: 12))
                        }
                        VStack(alignment: .leading, spacing: 8) {
                            Text("密码").font(.subheadline.weight(.medium))
                            SecureField("输入密码", text: $password).textContentType(.password)
                                .padding(14).background(LabTheme.background, in: RoundedRectangle(cornerRadius: 12))
                        }
                        if !error.isEmpty { Text(error).font(.subheadline).foregroundStyle(.red).accessibilityLabel("错误：" + error) }
                        Button(busy ? "正在登录…" : "登录工作台") {
                            busy = true; error = ""
                            Task {
                                let supplied = password
                                password = ""
                                do { try await api.login(server: server, username: username, password: supplied) }
                                catch { self.error = error.localizedDescription }
                                busy = false
                            }
                        }.buttonStyle(LabPrimary()).disabled(busy || server.isEmpty || username.isEmpty || password.isEmpty)
                            .opacity(busy || server.isEmpty || username.isEmpty || password.isEmpty ? 0.55 : 1)
                    }.labCard()
                    Label("安全连接 · 密码不保存在手机", systemImage: "lock.shield").font(.footnote).foregroundStyle(LabTheme.muted)
                    Text("与网页同步。地址和会话仅保留于运行内存，关闭进程后需重新填写。").font(.footnote).foregroundStyle(LabTheme.muted)
                }.padding(20).frame(maxWidth: 600)
                    .frame(maxWidth: .infinity)
            }.background(LabTheme.background).toolbar(.hidden, for: .navigationBar)
                .scrollDismissesKeyboard(.interactively)
                .onAppear { server = api.origin }
        }
    }
}

struct CSVDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}
struct LedgerView: View {
    @EnvironmentObject var api: API
    @State private var ledger: Ledger?
    @State private var projects: [PurchaseProject] = []
    @State private var projectID: Int?
    @State private var choosingProject = false
    var projectName: String { projects.first { $0.id == projectID }?.name ?? "请选择项目" }
    @State private var query = ""
    @State private var filter = "all"
    @State private var editing: Purchase?
    @State private var adding = false
    @State private var busy = false
    @State private var error = ""
    @State private var document: CSVDocument?
    @State private var exporting = false
    var filtered: [Purchase] {
        (ledger?.items ?? []).filter {
            (filter == "all" || $0.status == filter) && (query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) || $0.project.localizedCaseInsensitiveContains(query) || $0.notes.localizedCaseInsensitiveContains(query))
        }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 16) {
                    LabBrand()
                    summaryCard
                    Button { adding = true } label: { Label("添加采购记录", systemImage: "plus") }
                        .buttonStyle(LabPrimary()).disabled(projectID == nil).opacity(projectID == nil ? 0.5 : 1)
                    Picker("采购状态", selection: $filter) {
                        Text("全部").tag("all"); Text("待买").tag("planned"); Text("已买").tag("purchased")
                    }.pickerStyle(.segmented)
                    if !error.isEmpty { Text(error).font(.subheadline).foregroundStyle(.red).labCard() }
                    if ledger != nil && filtered.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("这里还没有记录").font(.headline)
                            Text(query.isEmpty ? "添加第一笔采购，或切换上面的分类。" : "试试其他关键词，或切换分类。").foregroundStyle(LabTheme.muted)
                        }.labCard()
                    }
                    ForEach(filtered) { item in
                        Button { editing = item } label: { PurchaseCard(item: item) }.buttonStyle(.plain)
                    }
                    Text("金额为整笔实付，不是单价。未知金额不计入实付总额。").font(.footnote).foregroundStyle(LabTheme.muted)
                }.padding(20).frame(maxWidth: 720).frame(maxWidth: .infinity)
            }.background(LabTheme.background)
            .navigationTitle("项目采购管理").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "在当前项目搜索名称或备注")
            .refreshable { await refresh() }.task { await initialize() }
            .onChange(of: projectID) { _ in ledger = nil; query = ""; filter = "all"; Task { await refresh() } }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { Task { await export() } } label: { Image(systemName: "square.and.arrow.up").frame(minWidth: 44, minHeight: 44) }
                        .disabled(busy || projectID == nil).accessibilityLabel("导出当前项目 CSV 报表")
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button { choosingProject = true } label: { Label("切换项目", systemImage: "folder") }
                        Button { Task { await refresh() } } label: { Label("刷新记录", systemImage: "arrow.clockwise") }
                        Button("退出登录", role: .destructive) { Task { try? await api.logout() } }
                    } label: { Image(systemName: "ellipsis.circle").frame(minWidth: 44, minHeight: 44) }.accessibilityLabel("更多操作")
                }
            }
            .sheet(isPresented: $choosingProject) { projectPicker }
            .sheet(isPresented: $adding) {
                if let id = projectID { EditView(item: nil, projectID: id, projectName: projectName) { await refresh() }.environmentObject(api) }
            }
            .sheet(item: $editing) { item in
                if let id = projectID { EditView(item: item, projectID: id, projectName: projectName) { await refresh() }.environmentObject(api) }
            }
            .fileExporter(isPresented: $exporting, document: document, contentType: .commaSeparatedText,
                          defaultFilename: "项目采购报表-\(Date().formatted(.iso8601).replacingOccurrences(of: ":", with: "-"))") { result in
                if case .failure(let failure) = result { error = failure.localizedDescription }
                document = nil
            }
        }
    }
    private var summaryCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("当前项目").font(.caption.weight(.semibold)).foregroundStyle(LabTheme.muted)
                Spacer()
                Button("切换项目") { choosingProject = true }.font(.subheadline.weight(.semibold)).frame(minHeight: 44)
            }
            Text(projectName).font(.title2.bold()).foregroundStyle(LabTheme.ink)
            if let s = ledger?.summary {
                Text("累计实付总额").font(.subheadline).foregroundStyle(LabTheme.muted)
                Text("¥ \(yuan(s.actual_cents))").font(.system(.largeTitle, design: .rounded).bold()).foregroundStyle(LabTheme.green)
                Divider()
                HStack {
                    metric("待买", s.planned_count); Spacer(); metric("已买", s.purchased_count); Spacer(); metric("金额待补", s.unknown_count)
                }
            } else if projectID != nil {
                ProgressView("正在读取项目记录…")
            } else {
                Text(projects.isEmpty ? "暂无项目，请先在网页后台创建项目。" : "选择一个项目，开始记录采购。").foregroundStyle(LabTheme.muted)
            }
        }.labCard()
    }
    private func metric(_ title: String, _ value: Int) -> some View {
        VStack(alignment: .leading, spacing: 4) { Text("\(value)").font(.title2.bold()); Text(title).font(.caption).foregroundStyle(LabTheme.muted) }
    }
    private var projectPicker: some View {
        NavigationStack {
            List {
                Section { Text("每个项目独立统计、独立导出。").foregroundStyle(LabTheme.muted) }
                ForEach(projects) { project in
                    Button { projectID = project.id; choosingProject = false } label: {
                        HStack(spacing: 14) {
                            Image(systemName: "folder.fill").foregroundStyle(LabTheme.green)
                            Text(project.name).font(.headline).foregroundStyle(LabTheme.ink)
                            Spacer()
                            if project.id == projectID { Image(systemName: "checkmark.circle.fill").foregroundStyle(LabTheme.green) }
                        }.padding(.vertical, 12)
                    }
                }
                if projects.isEmpty { Text("暂无项目，请先在网页后台创建项目。").foregroundStyle(LabTheme.muted) }
            }.scrollContentBackground(.hidden).background(LabTheme.background)
                .navigationTitle("我的采购项目").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { choosingProject = false } } }
        }
    }
    func initialize() async {
        do {
            projects = try await api.projects()
            projectID = projects.first(where: { $0.name == "DWARF 智能天文台" })?.id
            if projectID == nil && projects.count == 1 { projectID = projects.first?.id }
            // onChange triggers the scoped fetch; no global ledger request.
        } catch { self.error = error.localizedDescription }
    }
    func refresh() async {
        guard let selected = projectID else { ledger = nil; return }
        do {
            let result = try await api.load(projectID: selected)
            if projectID == selected { ledger = result; error = "" }
        } catch { if projectID == selected { self.error = error.localizedDescription } }
    }
    func export() async {
        guard let selected = projectID else { return }
        busy = true; defer { busy = false }
        do {
            document = CSVDocument(data: try await api.request("/api/admin/purchases/export.csv?project_id=\(selected)"))
            exporting = true
        } catch { self.error = error.localizedDescription }
    }
}
struct PurchaseCard: View {
    let item: Purchase
    private var planned: Bool { item.status == "planned" }
    private var stateTitle: String { planned ? "待采购" : item.amount_cents == nil ? "已购买 · 金额待补" : "已购买" }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(stateTitle).font(.caption.weight(.bold)).padding(.horizontal, 10).padding(.vertical, 6)
                .foregroundStyle(planned ? Color(red: 0.54, green: 0.33, blue: 0.07) : LabTheme.green)
                .background(planned ? Color(red: 1, green: 0.95, blue: 0.86) : LabTheme.pale, in: Capsule())
            Text(item.name).font(.headline).foregroundStyle(LabTheme.ink).multilineTextAlignment(.leading)
            if !planned, let cents = item.amount_cents { Text("¥ \(yuan(cents))").font(.title2.bold()).foregroundStyle(LabTheme.ink) }
            Text("数量：\(item.quantity.map(String.init) ?? "待确认")").font(.subheadline).foregroundStyle(LabTheme.muted)
            if !item.notes.isEmpty { Text(item.notes).font(.subheadline).foregroundStyle(LabTheme.muted).lineLimit(3) }
            HStack { Text(planned ? "已买，补记花费" : "编辑这条记录"); Spacer(); Image(systemName: "chevron.right") }
                .font(.subheadline.weight(.semibold)).foregroundStyle(LabTheme.green).frame(minHeight: 44)
        }.labCard()
    }
}
struct EditView: View {
    @EnvironmentObject var api: API
    @Environment(\.dismiss) private var dismiss
    let item: Purchase?
    let projectID: Int
    let projectName: String
    let saved: () async -> Void
    @State private var name: String
    @State private var quantity: String
    @State private var amount: String
    @State private var status: String
    @State private var notes: String
    @State private var busy = false
    @State private var error = ""
    @State private var uncertain = false
    init(item: Purchase?, projectID: Int, projectName: String, saved: @escaping () async -> Void) {
        self.item = item; self.projectID = projectID; self.projectName = projectName; self.saved = saved
        _name = State(initialValue: item?.name ?? "")
        _quantity = State(initialValue: item == nil ? "1" : item?.quantity.map(String.init) ?? "")
        _amount = State(initialValue: item?.amount_cents.map(yuan) ?? "")
        _status = State(initialValue: item?.status ?? "planned")
        _notes = State(initialValue: item?.notes ?? "")
    }
    var body: some View {
        NavigationStack {
            Form {
                Section { LabBrand(); Text(projectName).font(.headline).foregroundStyle(LabTheme.ink) } header: { Text("所属项目") }
                Section("只填名称即可保存待买") {
                    TextField("物品名称（必填）", text: $name)
                    Picker("状态", selection: $status) { Text("待买").tag("planned"); Text("已买").tag("purchased") }
                    TextField("实付总额，元（可留空）", text: $amount).keyboardType(.decimalPad)
                        .onChange(of: amount) { v in if !v.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { status = "purchased" } }
                    Text("实付填写整笔总额，不是单价。留空表示未知，不会算作零元。").font(.caption).foregroundStyle(.secondary)
                }
                DisclosureGroup("数量 / 备注（选填）") {
                    TextField("数量 · 默认 1", text: $quantity).keyboardType(.numberPad)
                    TextField("备注／规格／单位", text: $notes, axis: .vertical).lineLimit(3...8)
                    if let source = item?.source_ref { Text("来源：\(source)").font(.caption) }
                }
                if !error.isEmpty { Text(error).foregroundStyle(.red) }
                if uncertain {
                    Button("关闭并刷新核对结果") { Task { await saved(); dismiss() } }
                }
            }
            .scrollContentBackground(.hidden).background(LabTheme.background)
            .navigationTitle(item == nil ? "添加采购记录" : "编辑记录").navigationBarTitleDisplayMode(.inline)
            .interactiveDismissDisabled(busy)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() }.disabled(busy) }
                ToolbarItem(placement: .confirmationAction) { Button(busy ? "保存中…" : "保存") { Task { await save() } }.disabled(busy || uncertain || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
            }
        }
    }
    func save() async {
        var body: [String: Any]
        do {
            let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !n.isEmpty && n.count <= 160 && notes.count <= 1800 else { throw APIError(text: "名称最多160字，备注1800字") }
            let q = quantity.trimmingCharacters(in: .whitespacesAndNewlines)
            var qty: Any = NSNull()
            if q.isEmpty {
                guard item != nil && item?.quantity == nil else { throw APIError(text: "数量请输入正整数") }
            } else {
                guard q.range(of: #"^[0-9]+$"#, options: .regularExpression) != nil, let value = Int(q), (1...1_000_000).contains(value) else { throw APIError(text: "数量应为 1–1000000 的整数") }
                qty = value
            }
            let cents = try parseCents(amount)
            guard status != "planned" || cents == nil else { throw APIError(text: "待买不能填写实付金额，请清空金额或改为已买") }
            body = ["name": n, "quantity": qty, "status": status, "notes": notes,
                    "amount_cents": cents.map { $0 as Any } ?? NSNull()]
            if item == nil { body["project_id"] = projectID }
        } catch { self.error = error.localizedDescription; return }
        busy = true; defer { busy = false }
        do { try await api.save(id: item?.id, body: body); await saved(); dismiss() }
        catch {
            self.error = error.localizedDescription
            // Do not retry an uncertain mutation from the same form.
            uncertain = error.localizedDescription.contains("请求未确认")
        }
    }
}
