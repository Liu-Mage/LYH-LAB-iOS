# Windows 制作 iOS 安装包：GitHub Actions + SideStore

这是完整可编辑的 Xcode 源码，不是已安装验证的 iOS 成品。你可以在 Windows 管理源码，由 GitHub 的 macOS runner 编译，再在自己的 iPhone 用 SideStore 重签安装。**不需要为了这条个人侧载流程购买 Apple Developer 付费会员，但也不是永久免维护安装。**

## 1. 放好源码

在自己控制的 GitHub 仓库中，把源码目录的内容放到仓库根目录，不要只上传 ZIP：

```text
.github/workflows/ios-unsigned.yml
LYHLab.xcodeproj/
LYHLab/
Tests/
verify_source.py
```

Windows 可以通过 GitHub Desktop 提交，注意不要遗漏以点开头的 `.github` 文件夹。本次公开发布版已去除内置生产地址；不要上传真实密码、Apple 登录资料、设备配对文件、采购数据、签名密钥。工作流不需要你配置 Secrets，也不需要 Apple 账号。

## 2. 手动编译

把工作流提交到默认分支，在仓库 **Actions → Build unsigned iOS IPA → Run workflow** 中运行。工作流使用 `macos-15`、Xcode 的 `iphoneos` SDK，明确关闭代码签名，生成设备版本而不是模拟器版本。提交 main 分支且修改原生源码、工程、Tests、静态检查或本工作流时会自动构建；文档或 N1 参考代码单独更新不会触发。也保留手动触发入口。[GitHub 手动运行说明](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)

完成后，在运行页面的 **Artifacts** 下载 `LYHLab-iOS-unsigned-…`，解压后取出 `LYHLab-unsigned.ipa`；同时保留 SHA256SUMS.txt。红色失败时先看 `xcodebuild.log`，不要把失败日志包当成 IPA。[GitHub runner 说明](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)

工作流已经做源码结构检查、编译、IPA ZIP 完整性检查，但不做实际 iPhone 登录与运行测试。**这份工作流尚未在你的 GitHub 仓库运行，当前不能保证首次构建通过，也未生成实测 IPA。**

GitHub 公共仓库的标准 runner 与私有仓库的用量政策不同；私有仓库会消耗账号额度，超额可能收费。使用公共仓库的标准 macos-15 runner；如改为私有仓库或付费 runner，先核对额度和预算，不应未经确认开启收费。构建超时限制20分钟，产物保留7天。[GitHub Actions 计费](https://docs.github.com/en/billing/concepts/product-billing/github-actions)

## 3. 在 iPhone 用 SideStore 重签

先按当前 [SideStore 官方准备步骤](https://docs.sidestore.io/docs/installation/prerequisites) 和 [安装指南](https://docs.sidestore.io/docs/installation/install)，在 Windows 完成首次设置。官方当前流程涉及 USB、iloader、Apple Account 和 LocalDevVPN；只从官方页面链接取得工具，Apple 登录和设备信任由你本人操作，不把账号密码或配对文件传进 GitHub。

SideStore 安装完成后，把 **解压出来的 `.ipa` 文件**保存到 iPhone“文件”，在 SideStore 的 **My Apps** 使用添加 IPA 入口选择它，按 SideStore 提示完成个人重签。`.ipa` 不能直接像 Android APK 那样点开永久安装。应用需要 iOS 16 或更高；这里的用户名和密码是你的网站管理员账号，不是 Apple Account。

免费账号通常为7天开发签名，需要按时刷新；SideStore 官方说明同时安装上限为3个 App，包含 SideStore 自己，还有每周 App ID 数量限制。安装/刷新依赖其当前要求的网络和本地 VPN，失效后按官方文档处理，不承诺永不过期。[SideStore FAQ](https://docs.sidestore.io/docs/faq)

## 4. 首次检查

验证打开应用、网站账号登录、项目切换、真实记录读取。随后用明确的测试记录试一次新增/编辑及 CSV 导出，并确认没有混入其他项目。证书错误不能通过关闭 TLS 校验解决。若 SideStore 重签失败或 Xcode 构建失败，保留错误文本，但不要公开其中可能包含的 Apple 账号、设备信息或配对文件。

本方案没有上传 App Store/TestFlight，没有创建仓库，没有运行云构建，没有触碰服务器或打印机。

## 公开版地址配置
安装后在登录页填写本人真实 HTTPS 网站根地址，然后输入网站管理员账号。地址不随公开源码发布；不能填写 HTTP，也不能关闭证书验证。该地址和会话不写入磁盘。
