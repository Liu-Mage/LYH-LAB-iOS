import Foundation

@main struct ModelsSmoke {
    static func main() throws {
        let v2_ = try parseCents("")
        assert(v2_ == nil)
        let v3_0 = try parseCents("0")
        assert(v3_0 == 0)
        let v7_2112 = try parseCents("21.12")
        assert(v7_2112 == 2112)
        let v5_15 = try parseCents("1.5")
        assert(v5_15 == 150)
        let v9_1000000 = try parseCents("1000000")
        assert(v9_1000000 == 100000000)
        for s in ["-1", "0.001", "1e3", "1,000", "1000000.01", "nan"] {
            do { _ = try parseCents(s); fatalError("Accepted invalid input") } catch {}
        }
        assert(yuan(2112) == "21.12")
        let data = Data(#"{"items":[{"id":1,"name":"样例","quantity":null,"amount_cents":null,"status":"purchased","project":"","notes":"","source_ref":null,"updated_at":"2026-01-01"}],"summary":{"planned_count":0,"purchased_count":1,"actual_cents":0,"unknown_count":1}}"#.utf8)
        let ledger = try JSONDecoder().decode(Ledger.self, from: data)
        assert(ledger.items[0].quantity == nil && ledger.items[0].amount_cents == nil)
        let origin1 = try normalizedServerOrigin(" https://example.com/ "); assert(origin1 == "https://example.com")
        let origin2 = try normalizedServerOrigin("https://EXAMPLE.com:8443"); assert(origin2 == "https://example.com:8443")
        for bad in ["", "example.com", "http://example.com", "https://u:p@example.com", "https://example.com/path", "https://example.com?q=1", "https://example.com#x", "https://", "https://example.com:0"] {
            do { _ = try normalizedServerOrigin(bad); fatalError("Accepted invalid origin") } catch {}
        }
        print("PASS fixed-point amounts, unknown values and HTTPS origin validation")
    }
}
